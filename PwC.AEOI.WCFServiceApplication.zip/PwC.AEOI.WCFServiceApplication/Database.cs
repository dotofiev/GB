﻿using PwC.AEOI.WCFServiceApplication.Contracts.Data;
using System.Collections.Generic;

namespace PwC.AEOI.WCFServiceApplication
{
    public static class Database
    {
        public static List<Group> Groups = new List<Group>();
    }
}