﻿using PwC.AEOI.WCFServiceApplication.Contracts;
using PwC.AEOI.WCFServiceApplication.Contracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PwC.AEOI.WCFServiceApplication.Services
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ServiceGroup : IServiceGroup
    {
        public void Create(Group group)
        {
            group.Id = DateTime.Now.Ticks;
            group.CreationDate = DateTime.Now;

            Database.Groups.Add(group);
        }

        public void Delete(long id)
        {
            Database.Groups.RemoveAll(l => l.Id == id);
        }

        public Group Read(long id)
        {
            return Database.Groups.FirstOrDefault(l => l.Id == id);
        }

        public IEnumerable<Group> ReadAll()
        {
            return Database.Groups;
        }

        public void Update(long id, Group group)
        {
            var result = Database.Groups.FirstOrDefault(l => l.Id == id);

            if (result != null)
            {
                result.Title = group.Title;
            }
        }
    }
}
