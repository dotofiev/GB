﻿using System;
using System.Runtime.Serialization;

namespace PwC.AEOI.WCFServiceApplication.Contracts.Data
{
    /// <summary>
    /// Use a data contract as illustrated in the sample below to add composite types to service operations.
    /// </summary>
    [DataContract]
    public class Group
    {
        private long _id { get; set; }
        private string _title { get; set; }
        private DateTime _creationDate { get; set; }

        [DataMember]
        public long Id { get { return _id; } set { _id = value; } }

        [DataMember]
        public string Title { get { return _title; } set { _title = value; } }

        [DataMember]
        public DateTime CreationDate { get { return _creationDate; } set { _creationDate = value; } }
    }
}