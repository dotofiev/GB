﻿using PwC.AEOI.WCFServiceApplication.Contracts.Data;
using System.Collections.Generic;
using System.ServiceModel;

namespace PwC.AEOI.WCFServiceApplication.Contracts
{
    /// <summary>
    /// NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IServiceGroup" in both code and config file together.
    /// </summary>
    [ServiceContract]
    public interface IServiceGroup
    {
        [OperationContract]
        void Create(Group group);

        [OperationContract]
        Group Read(long id);

        [OperationContract]
        IEnumerable<Group> ReadAll();

        [OperationContract]
        void Update(long id, Group group);

        [OperationContract]
        void Delete(long id);
    }
}
